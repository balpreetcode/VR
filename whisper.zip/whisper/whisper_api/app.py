from flask import Flask, request
from flask_restful import Resource, Api
from werkzeug.utils import secure_filename
import os
import whisper

app = Flask(__name__)
api = Api(app)

UPLOAD_FOLDER = './uploads'
ALLOWED_EXTENSIONS = {'mp3', 'wav', 'flac'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

class TranscribeAudio(Resource):
    def post(self):
        if 'file' not in request.files:
            return {"error": "No file part in the request."}, 400
        file = request.files['file']
        if file.filename == '':
            return {"error": "No file selected."}, 400
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)

            # Load Whisper model
            model = whisper.load_model("base")
            result = model.transcribe(filepath)

            return {"transcript": result["text"]}

api.add_resource(TranscribeAudio, '/transcribe')

if __name__ == '__main__':
    app.run(debug=True)
